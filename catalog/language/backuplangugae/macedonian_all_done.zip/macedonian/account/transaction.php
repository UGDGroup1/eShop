<?php
// Heading 
$_['heading_title']      = 'Твоите трансакции';

// Column
$_['column_date_added']  = 'Дата на додавање';
$_['column_description'] = 'Опис';
$_['column_amount']      = 'Износ (%s)';

// Text
$_['text_account']       = 'Профил';
$_['text_transaction']   = 'Твоите трансакции';
$_['text_total']         = 'Твојата сегашна состојба е:';
$_['text_empty']         = 'Немате направено никакви трансакции!';
?>
