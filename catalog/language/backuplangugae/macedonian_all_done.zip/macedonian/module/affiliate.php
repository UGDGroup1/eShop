﻿<?php
// Heading 
$_['heading_title']    = 'Филијалата';

// Text
$_['text_register']    = 'Регистрирај се';
$_['text_login']       = 'најави се ';
$_['text_logout']      = 'одјави се';
$_['text_forgotten']   = 'Заборавена лозинка';
$_['text_account']     = 'Мој профил';
$_['text_edit']        = 'менувај профил';
$_['text_password']    = 'Лозинка';
$_['text_payment']     = 'Опции за плаќање';
$_['text_tracking']    = 'надблудување на филијалата';
$_['text_transaction'] = 'трансакции';
?>
