﻿<?php
// Heading 
$_['heading_title'] = 'Најпродавани';

// Text
$_['text_reviews']  = 'Врз основа на критика.'; 
?>