﻿<?php
$_['text_total'] = 'Вкупно!';
?>