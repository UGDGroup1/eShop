<?php
// Heading
$_['heading_title']     = 'Одржување';

// Text
$_['text_maintenance']  = 'Одржување';
$_['text_message']      = '<h1 style="text-align:center;">Моментално работиме на сајтот. <br/>Ќе го активираме што е мошно поскоро.</h1>';
?>
