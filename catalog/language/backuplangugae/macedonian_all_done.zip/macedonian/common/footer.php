<?php
// Text
$_['text_information']  = 'Информација';
$_['text_service']      = 'Услуги за клиенти';
$_['text_extra']        = 'Екстра';
$_['text_contact']      = 'Контакт';
$_['text_return']       = 'Враќања';
$_['text_sitemap']      = 'Мапа на сајтот';
$_['text_manufacturer'] = 'Брендови';
$_['text_voucher']      = 'Подарок купони';
$_['text_affiliate']    = 'Филијали';
$_['text_special']      = 'Акции';
$_['text_account']      = 'Мојот профил';
$_['text_order']        = 'Архива порачки';
$_['text_wishlist']     = 'Моја листа';
$_['text_newsletter']   = 'Информатор';
$_['text_powered']      = 'Направено од <br /> %s &copy; %s Сите права се задржани';
?>
