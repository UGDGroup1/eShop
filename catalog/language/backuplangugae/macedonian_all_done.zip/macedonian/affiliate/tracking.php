<?php
// Heading 
$_['heading_title']    = 'Надзор на филијалата';

// Text
$_['text_account']     = 'Профил';
$_['text_description'] = 'To make sure you get paid for referrals you send to us we need to track the referral by placing a tracking code in the URL\'s linking to us. You can use the tools below to generate links to the %s web site.';
$_['text_code']        = '<b>Твојот код за надгледување:</b>';
$_['text_generator']   = '<b>Генератор на линк за надгледување на трансферот</b><br />Напиши го името на продуктот:';
$_['text_link']        = '<b>Линк за надбљудување:</b>';
?>
