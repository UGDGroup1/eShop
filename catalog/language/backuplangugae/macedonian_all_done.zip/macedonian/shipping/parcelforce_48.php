﻿<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Ширина:'; 
$_['text_insurance']   = 'Осигуренo до:';   
$_['text_time']        = 'Проценето време: 48 часа'; 
?>