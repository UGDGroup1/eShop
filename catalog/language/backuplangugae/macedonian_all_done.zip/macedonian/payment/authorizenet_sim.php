﻿<?php
// Text
$_['text_title'] = 'Кредитна картичка / дебитна картичка (Authorize.Net)';
?>