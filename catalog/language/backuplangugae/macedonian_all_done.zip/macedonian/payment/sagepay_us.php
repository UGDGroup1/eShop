﻿<?php
// Text
$_['text_title']           = 'Кредитна картичка / дебитна картичка (SagePay)';
$_['text_credit_card']     = 'Кредитна картичка';
$_['text_wait']            = 'Ве молиме почекајте!';

// Entry
$_['entry_cc_owner']       = 'сопственичка карта:';
$_['entry_cc_number']      = 'Број на картата:';
$_['entry_cc_expire_date'] = 'Картичката важи до';
$_['entry_cc_cvv2']        = 'Карта заштитен код(CVV2):';
?>