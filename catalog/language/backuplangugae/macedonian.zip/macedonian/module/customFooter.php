<?php
// Heading 
$_['heading_title']  = 'Custom Footer';


// Kinder template language file - copy and translate this file into your language folder if you're using this theme with a language other than English

$_['payment_methods_text']  = 'Payment methods';
$_['store_text']  = 'Store';

$_['text_total']  = 'Total: ';
$_['multiple_items']  = 'Items: ';

$_['categories_text']  = 'Categories';

// Text
//Add any you need here, the same way described in the admin section.
?>