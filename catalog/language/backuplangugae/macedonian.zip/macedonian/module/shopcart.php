<?php

// Heading 
$_['heading_title']  = 'ShopCart theme options';

// Sale text
$_['sale_text']  = 'Sale';

// More text

$_['more_text']  = 'More...';
$_['less_text']  = 'Less...';

?>