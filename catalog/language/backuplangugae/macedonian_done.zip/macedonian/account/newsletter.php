<?php
// Heading 
$_['heading_title']    = 'Зачленување за информатор';

// Text
$_['text_account']     = 'Профил';
$_['text_newsletter']  = 'Информатор';
$_['text_success']     = 'Вие сте успешно зачленети за примање на информатор на вашата епошта, честито!';

// Entry
$_['entry_newsletter'] = 'Информатор:';
?>
