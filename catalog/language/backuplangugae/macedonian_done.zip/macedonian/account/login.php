<?php
// Heading 
$_['heading_title']                = 'Најава';

// Text
$_['text_account']                 = 'Профил';
$_['text_login']                   = 'Најава';
$_['text_new_customer']            = 'Нов клиент';
$_['text_register']                = 'Регистрирај Профил';
$_['text_register_account']        = 'Со креирање на овој профил Вие ке можете да купувате побрзо, да ги надгледувате вашите порачки.';
$_['text_returning_customer']      = 'Регистрирани купувачи';
$_['text_i_am_returning_customer'] = 'Јас сум регистриран купувач';
$_['text_forgotten']               = 'Заборавена лозинка';

// Entry
$_['entry_email']                  = 'E-пошта:';
$_['entry_password']               = 'Лозинка:';

// Error
$_['error_login']                  = 'Внимание: Не е пронајден таква е-пошта и лозинка';
?>
