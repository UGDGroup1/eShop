<?php
// Heading 
$_['heading_title']      = 'Вашите поени';

// Column
$_['column_date_added']  = 'Дата на додавање';
$_['column_description'] = 'Опис';
$_['column_points']      = 'Поени';

// Text
$_['text_account']       = 'Профил';
$_['text_reward']        = 'Поени';
$_['text_total']         = 'Вкупно поени:';
$_['text_empty']         = 'Немате поени :(';
?>
