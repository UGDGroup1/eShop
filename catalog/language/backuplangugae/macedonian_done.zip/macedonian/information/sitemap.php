﻿<?php
// Heading
$_['heading_title']    = 'Мапа на сајтот';
 
// Text
$_['text_special']     = 'Специјални понуди:';
$_['text_account']     = 'Мој профил:';
$_['text_edit']        = 'Информации за профилот:';
$_['text_password']    = 'Лозинка:';
$_['text_address']     = 'Именик';
$_['text_history']     = 'Подреди Историја';
$_['text_download']    = 'Превземања';
$_['text_cart']        = 'Кошничка';
$_['text_checkout']    = 'Плаќање';
$_['text_search']      = 'Барај';
$_['text_information'] = 'Информации';
 $_['text_contact']    = 'Контактирајте не ';
?>
