﻿<?php
// Heading 
$_['heading_title'] = 'Специјални';

// Text
$_['text_reviews']  = 'Врз основа на коментарите на %s.'; 
?>
