﻿<?php
// Heading 
$_['heading_title'] = 'Најнови';

// Text
$_['text_reviews']  = 'Врз основа на коментарите на% s.'; 
?>