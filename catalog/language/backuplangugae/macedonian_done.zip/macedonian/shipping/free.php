<?php
// Text
$_['text_title']       = 'Besplatna isporaka';
$_['text_description'] = 'Besplatna isporaka';
?>