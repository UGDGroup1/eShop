﻿<?php
// Text
$_['text_title']                 = 'Royal Mail';
$_['text_weight']                = 'Ширина:';
$_['text_insurance']             = 'Insured upto:';
$_['text_1st_class_standard']    = 'Прво класа стандарден пост';
$_['text_1st_class_recorded']    = 'Прва Класа Снимен пост';
$_['text_2nd_class_standard']    = 'Втора класа стандарден пост';
$_['text_2nd_class_recorded']    = 'Втора Класа Снимен пост';
$_['text_special_delivery_500']  = 'Специјална испорака следен ден(&pound;500)';
$_['text_special_delivery_1000'] = 'Специјални испорака Следен ден (&pound;1000)';
$_['text_special_delivery_2500'] = 'Специјални испорака Следен ден (&pound;2500)';
$_['text_standard_parcels']      = 'Стандардни парцели';
$_['text_airmail']               = 'Airmail';
$_['text_international_signed']  = 'Мегународно потпишан';
$_['text_airsure']               = 'Airsure';
$_['text_surface']               = 'Површина';
?>