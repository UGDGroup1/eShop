﻿<?php
// Text
$_['text_title'] = 'Кредитна картичка / дебитна картичка (Мал \ 's e-Commerce))';
?>