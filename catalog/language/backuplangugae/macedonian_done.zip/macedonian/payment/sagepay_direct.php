﻿<?php
// Text
$_['text_title']           = 'Кредитна картичка / дебитна картичка (SagePay)';
$_['text_credit_card']     = 'Кредитна картичка';
$_['text_start_date']      = '(ако е достапен)';
$_['text_issue']           = '(за Maестро и Соло картички само)';
$_['text_wait']            = 'Ве молиме почекајте!';

// Entry
$_['entry_cc_owner']       = 'споственичка карта:';
$_['entry_cc_type']        = 'видот на картичката:';
$_['entry_cc_number']      = 'Број на картичка:';
$_['entry_cc_start_date']  = 'Карта важи од Датум:';
$_['entry_cc_expire_date'] = 'рок на истекот на картата:';
$_['entry_cc_cvv2']        = 'Карта заштитен  код (CVV2):';
$_['entry_cc_issue']       = 'Картата Број:';
?>