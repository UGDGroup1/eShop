﻿<?php
// Entry
$_['entry_postcode'] = 'Поштенски код';
$_['entry_country']  = 'земја:';
$_['entry_zone']     = 'Регион / држава:';
?>