﻿<?php
// Text
$_['text_title'] = 'Плаќање';
?>