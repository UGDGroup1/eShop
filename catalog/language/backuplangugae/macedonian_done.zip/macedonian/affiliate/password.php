<?php
// Heading 
$_['heading_title']  = 'Промени лозинка';

// Text
$_['text_account']   = 'Профил';
$_['text_password']  = 'Твојата лозинка';
$_['text_success']   = 'Твојата лозинка беше запишана.';

// Entry
$_['entry_password'] = 'Лозинка:';
$_['entry_confirm']  = 'Потврди ја лозинката:';

// Error
$_['error_password'] = 'Лозинката мора да е помеѓу 4 и 20 карактери!';
$_['error_confirm']  = 'Лозинката и полето за потврда на лозинката не се исти!';
?>
