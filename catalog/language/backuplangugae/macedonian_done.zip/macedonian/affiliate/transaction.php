<?php
// Heading 
$_['heading_title']      = 'Твоите Трансакции';

// Column
$_['column_date_added']  = 'Дата';
$_['column_description'] = 'Опис';
$_['column_amount']      = 'Износ (%s)';

// Text
$_['text_account']       = 'Профил';
$_['text_transaction']   = 'Твоите Трансакции';
$_['text_balance']       = 'Тојата моментална состојба е:';
$_['text_empty']         = 'Немате трансакции!';
?>
