<?php
// Text
$_['text_home']     = 'Дома';
$_['text_wishlist'] = 'Моја листа (%s)';
$_['text_cart']     = 'Кошничка';
$_['text_items']    = '%s продукт(и) - %s';
$_['text_search']   = 'Пребарувај';
$_['text_welcome']  = 'Добредојде гостин, вие можете да се <a href="%s">логирате</a> или <a href="%s">креирате профил</a>.';
$_['text_logged']   = 'Вие сте логирани како <a href="%s">%s</a> <b>(</b> <a href="%s">Одјава</a> <b>)</b>';
$_['text_account']  = 'Мојот профил';
$_['text_checkout'] = 'Плати';
$_['text_language'] = 'Јазик';
$_['text_currency'] = 'Валута';
?>
