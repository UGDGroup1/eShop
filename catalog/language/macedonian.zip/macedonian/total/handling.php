<?php
$_['text_handling'] = 'Такса';
?>