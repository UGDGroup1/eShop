<?php
$_['text_credit']   = 'Продавница за кредит';
$_['text_order_id'] = 'цел проект: #%s';
?>