<?php
$_['text_low_order_fee'] = 'Надоместок за порачка!';
?>