<?php
// Heading
$_['heading_title'] = 'Твојот профил на филијала е креиран!';

// Text 
$_['text_approval'] = '<p>Благодарам</p>';
$_['text_account']  = 'Профил';
$_['text_success']  = 'Успех';
?>
