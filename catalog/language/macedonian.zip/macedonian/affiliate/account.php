<?php
// Heading 
$_['heading_title']        = 'Профил на филијала';

// Text
$_['text_account']         = 'Профил';
$_['text_my_account']      = 'Мојот филијален профил';
$_['text_my_tracking']     = 'Моите надгредувани трансакции';
$_['text_my_transactions'] = 'Моите трансакции';
$_['text_edit']            = 'Имена на информациите на профилот';
$_['text_password']        = 'Промена на лозинка';
$_['text_payment']         = 'Промена на методот на плаќање';
$_['text_tracking']        = 'Филијален надзорен код';
$_['text_transaction']     = 'Архива на трансакции';
?>
