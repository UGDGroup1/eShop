<?php
// Heading 
$_['heading_title'] = 'Одјава';

// Text
$_['text_message']  = '<p>Се одлогира успешно.</p>';
$_['text_account']  = 'Профил';
$_['text_logout']   = 'Одјава';
?>
