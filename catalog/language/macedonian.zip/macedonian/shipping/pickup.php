<?php
// Text
$_['text_title']       = 'Трансфер';
$_['text_description'] = 'трансфер од продавница';
?>