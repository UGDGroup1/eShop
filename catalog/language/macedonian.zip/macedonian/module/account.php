﻿<?php
// Heading 
$_['heading_title']    = 'Профил';

// Text
$_['text_register']    = 'Регистрирај се';
$_['text_login']       = 'најави се ';
$_['text_logout']      = 'Одјави се';
$_['text_forgotten']   = 'Заборавена лозинка';
$_['text_account']     = 'Мој профил';
$_['text_edit']        = 'Менувај профил';
$_['text_password']    = 'лозинка';
$_['text_wishlist']    = 'листа';
$_['text_order']       = 'Подреди Историја';
$_['text_download']    = 'Превземања';
$_['text_return']      = 'враќа';
$_['text_transaction'] = 'трансакции';
$_['text_newsletter']  = 'Билтен';
?>
