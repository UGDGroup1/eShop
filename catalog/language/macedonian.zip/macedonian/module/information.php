<?php
// Heading 
$_['heading_title'] = 'информации';

// Text
$_['text_contact']  = 'Контакт';
$_['text_sitemap']  = 'Мапа на сајтот';
?>