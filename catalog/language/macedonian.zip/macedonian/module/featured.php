<?php
// Heading 
$_['heading_title'] = 'Несшто';

$_['text_reviews']  = 'асдсс';
?>
