<?php
// Heading 
$_['heading_title']  = 'Фоотер';


// Kinder template language file - copy and translate this file into your language folder if you're using this theme with a language other than English

$_['payment_methods_text']  = 'Методи на плаќање';
$_['store_text']  = 'Продавница';

$_['text_total']  = 'Вкупно: ';
$_['multiple_items']  = 'Продукти: ';

$_['categories_text']  = 'Категории';

// Text
//Add any you need here, the same way described in the admin section.
?>
