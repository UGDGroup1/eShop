<?php

// Heading 
$_['heading_title']  = 'кошничка';

// Sale text
$_['sale_text']  = 'продажба';

// More text

$_['more_text']  = 'Повеќе ...';
$_['less_text']  = 'Помалку ';

?>