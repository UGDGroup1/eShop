<?php
// Heading 
$_['heading_title']   = 'Превземања';

// Text
$_['text_account']    = 'Профил';
$_['text_downloads']  = 'Превземања';
$_['text_order']      = 'Бр. Порачка:';
$_['text_date_added'] = 'Додадено на дата:';
$_['text_name']       = 'Име:';
$_['text_remaining']  = 'Останато:';
$_['text_size']       = 'Големина:';
$_['text_download']   = 'Превземања';
$_['text_empty']      = 'Немате направени претходни превземања!';
?>
