<?php
// Heading 
$_['heading_title']  = 'Промени лозинка';

// Text
$_['text_account']   = 'Профил';
$_['text_password']  = 'Твојата лозинка';
$_['text_success']   = 'Твојата лозинка е успешно променета.';

// Entry
$_['entry_password'] = 'Лозинка:';
$_['entry_confirm']  = 'Повтори ја лозинката:';

// Error
$_['error_password'] = 'Лозинката мора да биде помеѓу 4 и 20 карактери!';
$_['error_confirm']  = 'Лозинката и повтори ја лозинката не се исти!';
?>
