﻿<?php
// Text
$_['text_title']       = 'Кредитна картичка / дебитна картичка (SagePay)';
$_['text_description'] = 'Теми на Ред ';
?>