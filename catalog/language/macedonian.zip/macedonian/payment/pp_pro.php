﻿<?php
// Text
$_['text_title']           = 'Кредитна или дебитна картичка (преработени безбедно преку PayPal)';
$_['text_credit_card']     = 'Кредитна картичка';
$_['text_start_date']      = '(ако е достапен)';
$_['text_issue']           = '(за Маестро и Соло картички само)';
$_['text_wait']            = 'Ве молиме почекајте';

// Entry
$_['entry_cc_type']        = 'типот на мапата:';
$_['entry_cc_number']      = 'бројот на картичката:';
$_['entry_cc_start_date']  = 'Карта важи до Датум:';
$_['entry_cc_expire_date'] = 'рок на истекот на картичката:';
$_['entry_cc_cvv2']        = 'Карта Security Code (CVV2):';
$_['entry_cc_issue']       = 'Картата број:';
?>