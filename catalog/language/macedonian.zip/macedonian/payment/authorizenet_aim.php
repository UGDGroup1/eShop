﻿<?php
// Text
$_['text_title']           = 'Кредитна картичка / дебитна картичка (Authorize.Net)';
$_['text_credit_card']     = 'Кредитна картичка';
$_['text_wait']            = 'Ве молиме почекајте!';

// Entry
$_['entry_cc_owner']       = ' Сопственичка карта:';
$_['entry_cc_number']      = ' Број на карта:';
$_['entry_cc_expire_date'] = ' истекот на рокот на картата:';
$_['entry_cc_cvv2']        = 'Карта Security Code (CVV2):';
?>